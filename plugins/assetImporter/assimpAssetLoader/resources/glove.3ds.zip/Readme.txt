-=            Cartoon glove       	=-
-=        Modeled by Modeller      =-
-=          Alex Maslyukivskiy 	=-
-=	3D4U@mail.ru           =-
-=               01.24.2004            	=-

Cartoon gloves modelled and rendered in 3DMAX5 and then exported in:
*.max (low and hi-poly)
*.3ds (low and hi-poly)
*.dxf (low and hi-poly)
*.wrl (low and hi-poly)
+textures
Which is all included in archive.

-=Hi poly=-
Vertices:  2146
Polygons: 1072

-=Low poly =-
Vertices: 538
Faces: 256


My support by mail: 3D4U@mail.ru. 